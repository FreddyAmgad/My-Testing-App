const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ico = d => `<svg viewBox="0 0 24 24">${d}</svg>`;
const I = {
  home: ico('<path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/>'),
  chat: ico('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>'),
  cog: ico('<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>'),
  sync: ico('<path d="M20 11a8 8 0 0 0-14.5-3.5M4 4v4h4M4 13a8 8 0 0 0 14.5 3.5M20 20v-4h-4"/>'),
  bell: ico('<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 21h4"/>'),
  back: ico('<path d="M15 5l-7 7 7 7"/>'),
};

/* ---- page registry: add new resources here ---- */
const PAGES = {
  rumble: { icon: I.home, title: "Rumble", render: rumblePage },
  alerts: { icon: I.chat, title: "Alerts", render: soon },
  settings: { icon: I.cog, title: "Settings", render: soon },
};

const api = (p, o) => fetch("/api" + p, o).then(r => { if (!r.ok) throw new Error(r.status); return r.json(); });
const fmt = (n, d = 2) => n == null ? "n/a" : Number(n).toLocaleString("en", { maximumFractionDigits: d });
const sgn = n => n == null ? "n/a" : (n > 0 ? "+" : "") + fmt(n) + "%";
const cls = n => n == null ? "" : n >= 0 ? "up" : "down";
let timer;

function header(extra = "") {
  return `<div class="top"><div class="avatar">F</div><div class="sp"></div>${extra}</div>
  <h1>Hello 👋<span>Freddy</span></h1>`;
}
function photo(c) {
  return `<div class="photo">${c.logo ? `<img src="${esc(c.logo)}" alt="" onerror="this.remove()">` : ""}<span>${esc(c.ticker.slice(0, 2))}</span></div>`;
}
function soon(el, name) {
  el.innerHTML = header() + `<p class="sub">${name}</p><div class="empty">Nothing here yet.</div>`;
}

async function rumblePage(el, _, sub) {
  clearInterval(timer);
  if (sub) return detail(el, sub);
  let filter = "All", calls = [];
  const draw = () => {
    const shown = calls.filter(c => filter === "All" || (c.action || "").toLowerCase() === filter.toLowerCase());
    const alert = calls.some(c => c.in_range);
    el.innerHTML = header(`<button class="ib" id="sync" aria-label="Sync from Rumble">${I.sync}</button>
      <div class="ib" aria-label="Alerts">${I.bell}${alert ? '<i class="dot"></i>' : ""}</div>`) +
      `<p class="sub" id="st">${calls.length} active technical calls</p>
      <div class="tabs">${["All", "Buy", "Hold"].map(t => `<button class="tab ${t === filter ? "on" : ""}" data-f="${t}">${t}</button>`).join("")}</div>
      <div class="list">${shown.map(card).join("") || '<div class="empty">No calls yet. Press sync to pull them from Rumble.</div>'}</div>`;
    el.querySelectorAll(".tab").forEach(b => b.onclick = () => { filter = b.dataset.f; draw(); });
    el.querySelectorAll(".card").forEach(b => b.onclick = () => location.hash = "#/rumble/" + b.dataset.id);
    $("#sync").onclick = sync;
  };
  const load = async () => { try { calls = await api("/rumble/calls"); draw(); } catch (e) { el.innerHTML = header() + '<div class="empty">Backend not reachable.</div>'; } };
  async function sync() {
    $("#sync").classList.add("spin");
    await api("/rumble/harvest", { method: "POST" });
    const poll = setInterval(async () => {
      const s = await api("/rumble/status");
      const st = $("#st"); if (st) st.textContent = s.msg;
      if (!s.running) { clearInterval(poll); load(); }
    }, 2000);
  }
  await load();
  timer = setInterval(load, 30000);
}

function card(c) {
  return `<button class="card" data-id="${esc(c.id)}">${photo(c)}
    <div class="info">
      <div class="meta"><span class="tag ${c.action === "Buy" ? "buy" : ""}">${esc(c.action)}</span> ${esc(c.expert)}</div>
      <div class="tk">${esc(c.ticker)}</div>
      <div class="nm">${esc(c.name)}</div>
      <div class="row"><span class="px">${fmt(c.price)} EGP</span><span class="px ${cls(c.perf)}">${sgn(c.perf)}</span></div>
    </div></button>`;
}

async function detail(el, id) {
  el.innerHTML = '<div class="empty">Loading…</div>';
  let c;
  try { c = await api("/rumble/calls/" + encodeURIComponent(id)); }
  catch { el.innerHTML = '<a class="back" href="#/rumble">' + I.back + ' Back</a><div class="empty">Call not found.</div>'; return; }
  const range = c.buy_range ? `${fmt(c.buy_range[0])} to ${fmt(c.buy_range[1])}` : "n/a";
  const s = [["Open price", fmt(c.open_price)], ["Target", fmt(c.target)], ["Buy range", range],
    ["To target", sgn(c.to_target)], ["Since open", sgn(c.perf)], ["Stop loss", c.stop_loss === "HIDDEN" ? "Hidden" : esc(c.stop_loss || "n/a")],
    ["Opened", esc(c.opened_at || "n/a")], ["In buy range", c.in_range == null ? "n/a" : c.in_range ? "Yes" : "No"]];
  el.innerHTML = `<a class="back" href="#/rumble">${I.back} Back</a>
    <div class="hero">${photo(c)}<div><div class="tk">${esc(c.ticker)}</div><div class="nm">${esc(c.name)}</div>
    <div class="meta" style="margin-top:6px;color:#55554e">${esc(c.action)} by ${esc(c.expert)}</div></div></div>
    <div class="big">${fmt(c.price)} <small style="font-size:14px;font-weight:400;color:var(--mute)">EGP</small></div>
    <div class="meta">${c.source === "yahoo" ? "Live from Yahoo, " + esc(c.updated) : "Last price from Rumble"}</div>
    <div class="grid">${s.map(([k, v]) => `<div class="stat"><small>${k}</small><b>${v}</b></div>`).join("")}</div>
    <div class="story">${esc(c.body)}</div>
    <a class="ext" href="${esc(c.url)}" target="_blank" rel="noopener">Open on Rumble</a>`;
}

/* ---- router ---- */
function nav(page) {
  $("#nav").innerHTML = Object.entries(PAGES).map(([k, p]) => `<a href="#/${k}" class="${k === page ? "on" : ""}" aria-label="${p.title}">${p.icon}</a>`).join("");
}
function route() {
  clearInterval(timer);
  const [page = "rumble", sub] = location.hash.replace(/^#\/?/, "").split("/");
  const p = PAGES[page] || PAGES.rumble;
  nav(PAGES[page] ? page : "rumble");
  p.render($("#app"), p.title, sub);
  scrollTo(0, 0);
}
addEventListener("hashchange", route);
route();
