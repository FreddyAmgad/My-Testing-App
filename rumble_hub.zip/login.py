# Run once: logs you into Rumble by hand and saves the session in data/rumble_profile
from pathlib import Path
from playwright.sync_api import sync_playwright

PROFILE = str(Path(__file__).parent / "data" / "rumble_profile")
with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(PROFILE, headless=False)
    page = ctx.new_page()
    page.goto("https://therumble.app/login")
    input("Log in (email OTP), confirm you see /home, then press Enter... ")
    ctx.close()
