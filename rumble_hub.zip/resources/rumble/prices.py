import os, threading, time
import yfinance as yf
from .core import load_calls

INTERVAL = int(os.getenv("PRICE_INTERVAL", "300"))
SUFFIX = ".CA"
OVERRIDES = {}                 # {"EGAS": "EGAS.CA"} when a symbol differs
PRICES = {}                    # ticker -> {price, source, ts}


def live_price(sym):
    t = yf.Ticker(sym)
    try:
        p = t.fast_info["last_price"]
        if p and p == p:
            return float(p)
    except Exception:
        pass
    h = t.history(period="5d")
    return float(h["Close"].iloc[-1]) if len(h) else None


def refresh():
    for c in load_calls():
        tk = c["ticker"]
        try:
            p = live_price(OVERRIDES.get(tk, tk + SUFFIX))
        except Exception:
            p = None
        if p:
            PRICES[tk] = {"price": round(p, 3), "source": "yahoo", "ts": time.strftime("%H:%M:%S")}


def _loop():
    while True:
        try:
            refresh()
        except Exception as e:
            print("price loop error:", e)
        time.sleep(INTERVAL)


def start():
    threading.Thread(target=_loop, daemon=True).start()
