import re, threading, time
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright
from .core import PROFILE, save_calls

BASE = "https://therumble.app"
STATE = {"running": False, "msg": "idle", "last": None}


def parse_card(txt):
    lines = [l.strip() for l in txt.split("\n") if l.strip()]
    g = lambda i: lines[i] if len(lines) > i else ""
    d = {"name": g(0), "ticker": g(1), "action": g(2), "expert": g(3)}
    for label in ["Current Price", "Target Price", "Remaining Return", "Performance", "Opened"]:
        if label in lines:
            i = lines.index(label)
            d[label] = " ".join(lines[i + 1:i + 3]) if label in ("Current Price", "Target Price", "Opened") else lines[i + 1]
    return d


def get_logo(card):
    img = card.locator("img").first
    if not img.count():
        return ""
    src = img.get_attribute("src") or ""
    q = parse_qs(urlparse(src).query).get("url")
    return q[0] if q else src


def get_performance(dp):
    dp.get_by_role("tab", name="Performance").click()
    panel = dp.locator('div[role="tabpanel"][data-selected]')
    panel.wait_for(timeout=10000)
    return panel.evaluate(r"""el => {
      const out = {};
      el.querySelectorAll('button').forEach(b => {
        const lab = b.querySelector('span'); if (!lab) return;
        const label = lab.innerText.trim();
        let val = b.innerText.replace(label, '').trim().replace(/\s+/g, ' ');
        if (b.querySelector('.blur')) val = 'HIDDEN';
        out[label] = val;
      });
      return out;
    }""")


def load_all_cards(page):
    tab = page.get_by_role("tab", name=re.compile("Active"))
    tab.click()
    m = re.search(r"\[(\d+)\]", tab.inner_text())
    expected = int(m.group(1)) if m else None
    cards = page.locator('a[href^="/technical-calls/"]')
    last = stable = 0
    for _ in range(30):
        page.mouse.wheel(0, 5000); time.sleep(0.8)
        n = cards.count()
        if expected and n >= expected:
            break
        stable = stable + 1 if n == last else 0
        last = n
        if stable >= 4:
            break
    return cards


def _run():
    STATE.update(running=True, msg="starting")
    try:
        with sync_playwright() as p:
            ctx = p.chromium.launch_persistent_context(PROFILE, headless=True)
            page = ctx.new_page()
            page.goto(f"{BASE}/calls/technical", wait_until="domcontentloaded")
            page.wait_for_selector("main", timeout=20000); time.sleep(3)
            if "login" in page.url:
                STATE.update(msg="session expired: run python login.py")
                return
            cards = load_all_cards(page)
            items, seen = [], set()
            for i in range(cards.count()):
                c = cards.nth(i)
                href = c.get_attribute("href")
                if href in seen:
                    continue
                seen.add(href)
                d = parse_card(c.inner_text())
                d.update(href=href, id=href.rstrip("/").split("/")[-1], logo=get_logo(c))
                items.append(d)
            for n, d in enumerate(items, 1):
                STATE["msg"] = f"{n}/{len(items)} {d['ticker']}"
                dp = ctx.new_page()
                try:
                    dp.goto(BASE + d["href"], wait_until="domcontentloaded")
                    dp.wait_for_selector("main", timeout=15000); time.sleep(2)
                    try:
                        d["performance"] = get_performance(dp)
                    except Exception as e:
                        d["performance"] = {"error": str(e)}
                    for t in ["The Story", "Updates"]:
                        tb = dp.get_by_role("tab", name=t)
                        if tb.count():
                            tb.first.click(); time.sleep(0.8)
                    d["body"] = dp.locator("main").inner_text()
                except Exception as e:
                    d["body"] = f"ERROR loading page: {e}"
                dp.close(); time.sleep(1)
            save_calls(items)
            ctx.close()
            STATE.update(msg=f"done: {len(items)} calls", last=time.strftime("%Y-%m-%d %H:%M:%S"))
    except Exception as e:
        STATE["msg"] = f"error: {e}"
    finally:
        STATE["running"] = False


def start():
    if STATE["running"]:
        return False
    threading.Thread(target=_run, daemon=True).start()
    return True
