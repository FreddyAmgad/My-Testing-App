import re
from fastapi import APIRouter, HTTPException
from .core import load_calls, num
from .prices import PRICES
from . import harvest

router = APIRouter()


def enrich(c, full=False):
    perf = c.get("performance", {})
    lp = PRICES.get(c["ticker"])
    price = lp["price"] if lp else num(perf.get("Current Price") or c.get("Current Price"))
    openp = num(perf.get("Open Price"))
    target = num(perf.get("Final Target Price") or c.get("Target Price"))
    rng = [float(x) for x in re.findall(r"[\d.]+", perf.get("Buy Range", ""))]
    out = {
        "id": c.get("id"), "ticker": c["ticker"], "name": c.get("name"), "action": c.get("action"),
        "expert": c.get("expert"), "logo": c.get("logo"), "url": "https://therumble.app" + c.get("href", ""),
        "price": price, "source": lp["source"] if lp else "rumble", "updated": lp["ts"] if lp else None,
        "open_price": openp, "target": target, "buy_range": rng if len(rng) == 2 else None,
        "opened_at": perf.get("Opened At") or c.get("Opened"),
        "stop_loss": perf.get("Stop Loss"),
        "perf": round((price / openp - 1) * 100, 2) if price and openp else None,
        "to_target": round((target / price - 1) * 100, 2) if price and target else None,
        "in_range": (rng[0] <= price <= rng[1]) if price and len(rng) == 2 else None,
    }
    if full:
        out["body"] = c.get("body", "")
    return out


@router.get("/calls")
def calls():
    return [enrich(c) for c in load_calls()]


@router.get("/calls/{call_id}")
def call(call_id: str):
    for c in load_calls():
        if c.get("id") == call_id:
            return enrich(c, full=True)
    raise HTTPException(404, "call not found")


@router.post("/harvest")
def run_harvest():
    return {"started": harvest.start(), **harvest.STATE}


@router.get("/status")
def status():
    return harvest.STATE
