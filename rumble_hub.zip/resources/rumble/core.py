import json, re
from pathlib import Path

DATA = Path(__file__).resolve().parents[2] / "data"
DATA.mkdir(exist_ok=True)
CALLS = DATA / "rumble_calls.json"
PROFILE = str(DATA / "rumble_profile")


def num(s):
    m = re.search(r"[\d.]+", (s or "").replace(",", ""))
    return float(m.group()) if m else None


def load_calls():
    return json.loads(CALLS.read_text("utf-8")) if CALLS.exists() else []


def save_calls(x):
    CALLS.write_text(json.dumps(x, ensure_ascii=False, indent=2), "utf-8")
