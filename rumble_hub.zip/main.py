from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from resources.rumble import prices
from resources.rumble.router import router as rumble_router

ROOT = Path(__file__).parent


@asynccontextmanager
async def lifespan(app):
    prices.start()          # background live-price loop
    yield


app = FastAPI(title="Hub", lifespan=lifespan)

# every resource gets its own prefix: /api/<resource>
app.include_router(rumble_router, prefix="/api/rumble", tags=["rumble"])


@app.get("/api/health")
def health():
    return {"ok": True}


app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


@app.get("/{path:path}", include_in_schema=False)
def spa(path: str):
    if path.startswith("api"):
        raise HTTPException(404)
    return FileResponse(ROOT / "static" / "index.html")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
